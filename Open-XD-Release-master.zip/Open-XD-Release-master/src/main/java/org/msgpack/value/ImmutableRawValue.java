package org.msgpack.value;

public interface ImmutableRawValue extends RawValue, ImmutableValue {
}
