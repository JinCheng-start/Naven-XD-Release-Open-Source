package org.msgpack.value;

public interface ImmutableTimestampValue extends TimestampValue, ImmutableValue {
}
