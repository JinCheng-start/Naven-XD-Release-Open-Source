package org.msgpack.value;

public interface BinaryValue extends RawValue {
}
