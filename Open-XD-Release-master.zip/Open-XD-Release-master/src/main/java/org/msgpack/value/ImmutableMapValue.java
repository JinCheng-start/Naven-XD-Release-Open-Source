package org.msgpack.value;

public interface ImmutableMapValue extends MapValue, ImmutableValue {
}
