package org.msgpack.value;

public interface ImmutableBooleanValue extends BooleanValue, ImmutableValue {
}
