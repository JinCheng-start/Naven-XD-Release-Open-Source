package org.msgpack.value;

public interface StringValue extends RawValue {
}
