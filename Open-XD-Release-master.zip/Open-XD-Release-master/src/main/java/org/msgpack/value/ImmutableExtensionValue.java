package org.msgpack.value;

public interface ImmutableExtensionValue extends ExtensionValue, ImmutableValue {
}
