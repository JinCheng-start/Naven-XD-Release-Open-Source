package org.msgpack.value;

public interface ImmutableNilValue extends NilValue, ImmutableValue {
}
