package tech.naven;


import net.minecraftforge.fml.common.Mod;

@Mod("naven")
public class NavenModLoader {
}
