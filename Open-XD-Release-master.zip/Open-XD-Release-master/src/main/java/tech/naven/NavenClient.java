package tech.naven;

public class NavenClient {
    public static void main(String[] args) {
        String opai = "F3EF20DF-CCF9-4CAF-A6A7-4D64DF61B523";
    }
}