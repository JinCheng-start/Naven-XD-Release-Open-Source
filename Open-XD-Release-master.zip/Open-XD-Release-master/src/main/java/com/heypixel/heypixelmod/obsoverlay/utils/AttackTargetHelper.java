package com.heypixel.heypixelmod.obsoverlay.utils;

import net.minecraft.world.entity.Entity;

import java.util.ArrayList;
import java.util.List;

public class AttackTargetHelper {
   public static List<Entity> targets = new ArrayList<>();
}
