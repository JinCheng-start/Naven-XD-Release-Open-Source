package com.heypixel.heypixelmod.obsoverlay.events.api.events;

public interface Typed {
   byte getType();
}
