package com.heypixel.heypixelmod.obsoverlay.utils;

public interface ICapabilityTracker {
   boolean get();

   void set(boolean var1);
}
