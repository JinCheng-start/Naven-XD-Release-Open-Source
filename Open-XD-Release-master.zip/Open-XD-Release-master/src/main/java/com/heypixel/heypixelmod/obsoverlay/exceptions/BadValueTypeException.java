package com.heypixel.heypixelmod.obsoverlay.exceptions;

public class BadValueTypeException extends RuntimeException {
}
