package com.heypixel.heypixelmod.obsoverlay.annotations;

public @interface FlowExclude {
}
