package com.heypixel.heypixelmod.obsoverlay;

public class Version {
    public static String getVersion() {
            return "Alpha 1.6.1";
        }
    }