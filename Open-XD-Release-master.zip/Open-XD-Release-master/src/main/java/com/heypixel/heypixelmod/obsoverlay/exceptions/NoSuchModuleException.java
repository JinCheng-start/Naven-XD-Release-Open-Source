package com.heypixel.heypixelmod.obsoverlay.exceptions;

public class NoSuchModuleException extends RuntimeException {
   public static Object r;
   public static Object s;
}
