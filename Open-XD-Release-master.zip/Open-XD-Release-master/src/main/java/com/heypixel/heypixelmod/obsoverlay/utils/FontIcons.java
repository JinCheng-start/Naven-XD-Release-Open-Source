package com.heypixel.heypixelmod.obsoverlay.utils;

public class FontIcons {
       public static String RESIZE = "\ue904";
   public static String SWORD = "\ue903";
   public static String RUNNING = "\ue902";
   public static String EYE = "\ue901";
   public static String OTHER = "\ue900";
    public static String MUSIC = "\ue905";
}
