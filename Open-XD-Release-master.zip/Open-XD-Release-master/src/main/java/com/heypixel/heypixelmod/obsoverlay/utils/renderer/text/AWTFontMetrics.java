package com.heypixel.heypixelmod.obsoverlay.utils.renderer.text;

import java.awt.*;

public class AWTFontMetrics extends FontMetrics {
   public AWTFontMetrics(java.awt.Font font) {
      super(font);
   }
}
