package com.heypixel.heypixelmod.obsoverlay.values;

public enum ValueType {
   BOOLEAN,
   FLOAT,
   INTEGER,
   MODE,
   STRING;
}