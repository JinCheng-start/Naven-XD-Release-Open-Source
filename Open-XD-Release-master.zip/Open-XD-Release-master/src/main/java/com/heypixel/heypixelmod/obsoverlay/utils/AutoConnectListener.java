package com.heypixel.heypixelmod.obsoverlay.utils;

/**
 * 自动连接监听器
 * 用于处理自动连接相关的事件
 */
public class AutoConnectListener {
    
    public AutoConnectListener() {
        // 构造函数
    }
    
    // 可以在这里添加自动连接相关的逻辑
}